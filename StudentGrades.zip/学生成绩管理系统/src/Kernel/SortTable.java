package Kernel;

import java.util.Comparator;

public class SortTable implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		if(o1.getID().compareTo(o2.getID()) >= 0){
			return 1;
		}else{
			return -1;
		}
	}

}
