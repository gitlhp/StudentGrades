package Kernel;

import UI.MainFrame;

public class MyUtil {
	public static void updateTable(Manager m, MainFrame mf){
		// clear table 
		int nRowCount = mf.getModel().getRowCount();
		for(int i = 0; i < nRowCount; i ++){
			mf.getModel().removeRow(0);
		}
		// add items
		for(int j = 0; j < m.getStudentCount(); j ++){
			String[] rowData = {String.valueOf(j+1), 
					m.getStudent(j).getID(), 
					m.getStudent(j).getName(), 
					m.getStudent(j).getClas(), 
					String.valueOf(m.getStudent(j).getGrade(0)),
					String.valueOf(m.getStudent(j).getGrade(1)), 
					String.valueOf(m.getStudent(j).getGrade(2)), 
					String.valueOf(m.getStudent(j).getAveGrade()), 
					String.valueOf(m.getStudent(j).getTotalGrade())};
			mf.getModel().addRow(rowData);
		}
		// Update lblInfo
		mf.lblInfo.setText("��Ŀһ��" + m.getAveGrade(0)+"/"+m.getTotalGrade(0)
				+"      ��Ŀ����"+ m.getAveGrade(1)+"/"+m.getTotalGrade(1)
				+"      ��Ŀ����"+ m.getAveGrade(2)+"/"+m.getTotalGrade(2));
	}
	public static boolean checkNum(String s){
		for(int i = 0; i < s.length(); i ++){
			if(s.charAt(i) >= '0' && s.charAt(i) <= '9' || s.charAt(i) <= '.'){
				// .. 
			}else{
				return false;
			}
		}
		return true;
	}

}
