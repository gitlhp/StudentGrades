package Kernel;

public class Student {
	private String name;
	private String ID;
	private String Clas;
	private double[] grade = new double[3];
	public Student(String name, String id, String clas,
					double g1, double g2, double g3) {
		super();
		grade[0] = g1; grade[1] = g2; grade[2] = g3;
		this.name = name;
		ID = id;
		Clas = clas;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getID() {
		return ID;
	}
	public void setID(String id) {
		ID = id;
	}
	public String getClas() {
		return Clas;
	}
	public void setClas(String clas) {
		Clas = clas;
	}
	public double setGrade(int index, double grade){
		return this.grade[index] = grade;
	}
	public double getGrade(int index){
		return this.grade[index];
	}
	public double getTotalGrade(){
		return grade[0] + grade[1] + grade[2];
	}
	public double getAveGrade(){
		return getTotalGrade()/3.0;
	}
}
