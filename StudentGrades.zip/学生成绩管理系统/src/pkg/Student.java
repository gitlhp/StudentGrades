package pkg;
public class Student {
    private   String name;
    private   String ID;
    private   String clas;
    private   double grade1,grade2,grade3; 
	public Student(String name, String id, String clas, double grade1,
			double grade2, double grade3){//����
		super();
		this.name = name;
		this.ID = id;
		this.clas = clas;
		this.grade1 = grade1;
		this.grade2 = grade2;
		this.grade3 = grade3;//���캯��
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getID() {
		return ID;
	}
	public void setID(String id) {
		ID = id;
	}
	public String getClas() {
		return clas;
	}
	public void setClas(String clas) {
		this.clas = clas;
	}
	public double getGrade1() {
		return grade1;
	}
	public void setGrade1(double grade1) {
		this.grade1 = grade1;
	}
	public double getGrade2() {
		return grade2;
	}
	public void setGrade2(double grade2) {
		this.grade2 = grade2;
	}
	public double getGrade3() {
		return grade3;
	}
	public void setGrade3(double grade3) {
		this.grade3 = grade3;
	}
}//����ĳ�ʼ��

    
