package pkg;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

class MyFile1{
	public static void saveFile(String dest, String content){//·������Ϣ
		try {
			FileOutputStream fout;//�ļ�����ֽ���
			fout = new FileOutputStream(dest, true);
			byte[] bOut=content.getBytes();
			fout.write(bOut);
			fout.write(13);fout.write(10);//����13\r   10\n
			fout.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
