package Interface;

import UI.MainFrame;

public class Luncher {
	public static void main(String argv[]){
		MainFrame mf= new MainFrame();
		mf.setVisible(true);
	}
}
