package UI;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Kernel.MyUtil;
import Kernel.Student;

public class ModifyStudentFrame extends JFrame implements ActionListener {
	private MainFrame c = null;
	private int i = 0;

	private JTextField txtName = new JTextField("");
	private JTextField txtID = new JTextField("");
	private JTextField txtClas = new JTextField("");
	private JTextField txtGrade1 = new JTextField("");
	private JTextField txtGrade2 = new JTextField("");
	private JTextField txtGrade3 = new JTextField("");

	private JButton btnSave = new JButton("�޸�");
	private JButton btnCancel = new JButton("ȡ��");

	ModifyStudentFrame(MainFrame p){
		super("�޸�ѧ����Ϣ");
		this.c = p;

		this.setLayout(new GridLayout(7, 2));
		this.add(new JLabel("    ����"));		this.add(txtName);
		this.add(new JLabel("    �༶"));		this.add(txtClas);
		this.add(new JLabel("    ѧ��"));		this.add(txtID);
		this.add(new JLabel("    �༭��"));		this.add(txtGrade1);
		this.add(new JLabel("    ������"));		this.add(txtGrade2);
		this.add(new JLabel("    ����"));		this.add(txtGrade3);

		this.add(btnSave);	this.add(btnCancel);
		this.btnSave.addActionListener(this);
		this.btnCancel.addActionListener(this);

		this.setBounds(200, 200, 300, 300);
		this.setVisible(true);
	}

	public void update(int i){
		this.i = i;
		this.txtName.setText(c.m.getStudent(i).getName());
		this.txtClas.setText(c.m.getStudent(i).getClas());
		this.txtID.setText(c.m.getStudent(i).getID());
		this.txtGrade1.setText(String.valueOf(c.m.getStudent(i).getGrade(0)));
		this.txtGrade2.setText(String.valueOf(c.m.getStudent(i).getGrade(1)));
		this.txtGrade3.setText(String.valueOf(c.m.getStudent(i).getGrade(2)));
	}

	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == btnCancel){
			//this.setVisible(false);
			this.dispose();
		}else{
			// Check
			if(!MyUtil.checkNum(txtID.getText())){
				JOptionPane.showMessageDialog(null, "ID �������� ��");
				txtID.requestFocus();
				return ;
			}
			if(!MyUtil.checkNum(txtGrade1.getText())){
				JOptionPane.showMessageDialog(null, "�༭���������� ��");
				txtGrade1.requestFocus();
				return ;
			}
			if(!MyUtil.checkNum(txtGrade2.getText())){
				JOptionPane.showMessageDialog(null, "�������������� ��");
				txtGrade2.requestFocus();
				return ;
			}
			if(!MyUtil.checkNum(txtGrade3.getText())){
				JOptionPane.showMessageDialog(null, "������������ ��");
				txtGrade3.requestFocus();
				return ;
			}
			// Save
			Student st = c.m.getStudent(i);
			st.setName(txtName.getText());
			st.setID(txtID.getText());
			st.setClas(txtClas.getText());
			st.setGrade(0, Double.parseDouble(txtGrade1.getText()));
			st.setGrade(1, Double.parseDouble(txtGrade2.getText()));
			st.setGrade(2, Double.parseDouble(txtGrade3.getText()));

			MyUtil.updateTable(c.m, c);
			c.m.outputStudentInfo();
			this.dispose();
		}

	}

}
