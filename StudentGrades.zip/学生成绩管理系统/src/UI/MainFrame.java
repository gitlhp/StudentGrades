package UI;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import Kernel.Manager;
import Kernel.MyUtil;
import Kernel.Student;
public class MainFrame extends JFrame implements ActionListener {
	// Manager 
	public Manager m = new Manager();

	// Control
	private JPanel pBtn = new JPanel();

	private JButton btnAddStudent = new JButton("����");
	private JButton btnDelStudent = new JButton("ɾ��");
	private JButton btnFindStudent = new JButton("����");
	private JButton btnModifyStudent = new JButton("�޸�");
	private JButton btnSortStudent = new JButton("����");
	private JButton btnSaveStudent = new JButton("������Ϣ���ļ�");
	private JButton btnAbout = new JButton("����");
	private JButton btnQuit = new JButton("�˳�");
	public  JLabel  lblInfo = new JLabel("��Ϣ");

	// ���
	AddStudentFrame addStudentUI = null;
	private ModifyStudentFrame modifyStudentUI = null;

	// ����ؼ�
	private DefaultTableModel model = new DefaultTableModel();
	private JTable table = new JTable(model);
	private JScrollPane ps = new JScrollPane();

	public MainFrame(){
		super("��վ����ϵͳ");
		btnAddStudent.addActionListener(this);
		btnDelStudent.addActionListener(this);
		btnFindStudent.addActionListener(this);
		btnModifyStudent.addActionListener(this);
		btnSaveStudent.addActionListener(this);
		btnAbout.addActionListener(this);
		btnQuit.addActionListener(this);
		btnSortStudent.addActionListener(this);
		pBtn.add(btnAddStudent);	
		pBtn.add(btnDelStudent);	
		pBtn.add(btnFindStudent);	
		pBtn.add(btnModifyStudent);	
		pBtn.add(btnSortStudent);
		pBtn.add(btnAbout);	
		pBtn.add(btnSaveStudent);	
		pBtn.add(btnQuit);
		this.add(pBtn, BorderLayout.NORTH);
		this.add(lblInfo, BorderLayout.SOUTH);

		ps.getViewport().add(table);
		getContentPane().add(ps, BorderLayout.CENTER);
		model.addColumn("���");
		model.addColumn("��ϵ��ʽ"); model.addColumn("����"); 
		model.addColumn("ѧԺ"); model.addColumn("�༭��");
		model.addColumn("������"); model.addColumn("����");
		model.addColumn("��ע");model.addColumn("����");
		//	model.addRow(rowData);
		//	model.setValueAt("00", 1, 1);

		this.setBounds(100, 100, 800, 400);
		this.setDefaultCloseOperation(3);
	}

	public DefaultTableModel getModel(){
		return model;
	}
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == btnAddStudent){
			if(null == addStudentUI){
				addStudentUI = new AddStudentFrame(this);
			}else{
				addStudentUI.setVisible(true);
			}
		}
		if(arg0.getSource() == btnFindStudent){
			String str = JOptionPane.showInputDialog(null, "Please input ID :", "2014111");
			if(null == str){
				return ;
			}else{
				Student st = m.findSudent(str);
				if(null == st){
					JOptionPane.showMessageDialog(null,  "δ�ҵ���ѧ��!");
					return ;
				}
				int i = m.getIndex(st);
				//	table.setSelectionMode(i);
				table.setRowSelectionInterval(i, i);
			}
		}
		if(arg0.getSource() == btnDelStudent){
			int i[] = table.getSelectedRows();
			if(i.length <= 0){
				JOptionPane.showMessageDialog(null,  "ɶ�ӹ�ƨ���ⶼû��ѡ���أ��ס�");
				return ;
			}
			if(JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null, "����Ҫɾ�������Щ��ѧ����������г���")){
				for(int j = 0; j < i.length; j ++){
					m.deleteStudent(i[0]);
				}
				MyUtil.updateTable(m, this);
				JOptionPane.showMessageDialog(null,  "ɾ���ɹ���");
			}	
		}
		if(arg0.getSource() == btnModifyStudent){
			int[] i = table.getSelectedRows();
			if(i.length < 1){
				JOptionPane.showMessageDialog(null, "= = �� ɶ�Ӷ�û��ѡ�� ��");
				return ;
			}
			if(null == modifyStudentUI){
				modifyStudentUI = new ModifyStudentFrame(this);
			}else{
				modifyStudentUI.setVisible(true);
			}
			modifyStudentUI.update(i[0]);
		}
		if(arg0.getSource() == btnSortStudent){
			this.m.Sort0();
			MyUtil.updateTable(m, this);
		}
		if(arg0.getSource() == btnAbout){
			JOptionPane.showMessageDialog(null, "������ �� ����ӭ\nʱ�� �� 2015����\n��Ȩ���У���ð����˵һ������~");
		}
		if(arg0.getSource() == btnSaveStudent){
			this.m.saveToFile("C:\\StudentData.txt");
			JOptionPane.showMessageDialog(null,  "����ɹ� ��\nC:\\StudentData.txt");
		}
		if(arg0.getSource() == btnQuit){
			System.exit(3);
		}

	}

}
