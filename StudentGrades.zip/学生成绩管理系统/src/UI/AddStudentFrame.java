package UI;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Kernel.MyUtil;

@SuppressWarnings("serial")
public class AddStudentFrame extends JFrame implements ActionListener{
	private MainFrame c = null;

	private JTextField txtName = new JTextField("");
	private JTextField txtID = new JTextField("2014111");
	private JTextField txtClas = new JTextField("��������14");
	private JTextField txtGrade1 = new JTextField("100");
	private JTextField txtGrade2 = new JTextField("100");
	private JTextField txtGrade3 = new JTextField("100");

	private JButton btnSave = new JButton("����");
	private JButton btnCancel = new JButton("ȡ��");

	public AddStudentFrame(MainFrame p){
		super("����ѧ��");
		this.c = p;

		this.setLayout(new GridLayout(7, 2));
		this.add(new JLabel("    ����"));		this.add(txtName);
		this.add(new JLabel("    ѧԺ"));		this.add(txtClas);
		this.add(new JLabel("    ��ϵ��ʽ"));		this.add(txtID);
		this.add(new JLabel("    �༭��"));		this.add(txtGrade1);
		this.add(new JLabel("    ������"));		this.add(txtGrade2);
		this.add(new JLabel("    ����"));		this.add(txtGrade3);

		this.add(btnSave);	this.add(btnCancel);
		this.btnSave.addActionListener(this);
		this.btnCancel.addActionListener(this);

		this.setBounds(200, 200, 300, 300);
		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == btnCancel){
			//this.setVisible(false);
			this.dispose();
		}else{
			// Check
			if(!MyUtil.checkNum(txtID.getText())){
				JOptionPane.showMessageDialog(null, "ID �������� ��");
				txtID.requestFocus();
				return ;
			}
			if(!MyUtil.checkNum(txtGrade1.getText())){
				JOptionPane.showMessageDialog(null, "�༭���������� ��");
				txtGrade1.requestFocus();
				return ;
			}
			if(!MyUtil.checkNum(txtGrade2.getText())){
				JOptionPane.showMessageDialog(null, "�������������� ��");
				txtGrade2.requestFocus();
				return ;
			}
			if(!MyUtil.checkNum(txtGrade3.getText())){
				JOptionPane.showMessageDialog(null, "������������ ��");
				txtGrade3.requestFocus();
				return ;
			}
			// Save
			if(false == c.m.addStudent(txtName.getText(), txtID.getText(), txtClas.getText(),
					Double.parseDouble(txtGrade1.getText()), 
					Double.parseDouble(txtGrade2.getText()),
					Double.parseDouble(txtGrade3.getText()))){
				return ;
			}
			c.m.outputStudentInfo();
			MyUtil.updateTable(c.m, c);
			this.dispose();
		}

	}
}
